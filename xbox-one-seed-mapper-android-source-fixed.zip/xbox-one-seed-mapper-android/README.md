# Xbox One Legacy Seed Mapper — Android

Offline Android WebView shell for the personal Xbox One Edition seed mapper.

Important: this build intentionally does NOT invent results for arbitrary seeds. The UI and offline Android wrapper are implemented; the exact Legacy Console generation engine still needs to be ported/bundled.

Build with Android SDK/Gradle:

    gradle :app:assembleDebug

Output:

    app/build/outputs/apk/debug/app-debug.apk
